
# CHT22 — Dashboard Backend (Atualização Completa v27)
Instruções no corpo do ZIP. Este pacote atualiza o backend para ler a planilha via GViz.
