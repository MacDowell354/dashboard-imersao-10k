#!/usr/bin/env python3
"""
WSGI entry point for Dashboard CHT22
"""

from app_atualizado import app

if __name__ == "__main__":
    app.run()
